<?php
include '../include/db.php';
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userId']) || $_SESSION['userRole'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Ensure no output before header calls
ob_start(); // Start output buffering

// Variables
$adminId = $_SESSION['userId'];
$filterDepartment = isset($_GET['department']) ? $_GET['department'] : '';
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Query to fetch users with optional department and search filters
$query = "
SELECT sd.studentUserId, sd.studentFirstName, sd.studentLastName, sd.studentPhoneNumber,
       a.school_name, a.totalMarks,
       GROUP_CONCAT(DISTINCT p.preferenceDepartment ORDER BY p.preferenceOrder SEPARATOR ', ') AS preferenceDepartments,
       GROUP_CONCAT(DISTINCT p.preferenceStatus ORDER BY p.preferenceOrder SEPARATOR ', ') AS preferenceStatuses
FROM studentdetails sd
LEFT JOIN academic a ON sd.studentUserId = a.academicUserId
LEFT JOIN preference p ON sd.studentUserId = p.preferenceUserId
WHERE 1=1
";

// Apply department filter
if (!empty($filterDepartment)) {
    $query .= " AND p.preferenceDepartment = ?";
}

// Apply search filter
if (!empty($searchQuery)) {
    $query .= " AND (sd.studentFirstName LIKE ? OR sd.studentLastName LIKE ? OR sd.studentPhoneNumber LIKE ? OR a.school_name LIKE ?)";
}

$query .= " GROUP BY sd.studentUserId ORDER BY sd.studentUserId ASC";

$stmt = $conn->prepare($query);

if (!empty($filterDepartment) && !empty($searchQuery)) {
    $searchPattern = "%" . $searchQuery . "%";
    $stmt->bind_param("sssss", $filterDepartment, $searchPattern, $searchPattern, $searchPattern, $searchPattern);
} elseif (!empty($filterDepartment)) {
    $stmt->bind_param("s", $filterDepartment);
} elseif (!empty($searchQuery)) {
    $searchPattern = "%" . $searchQuery . "%";
    $stmt->bind_param("ssss", $searchPattern, $searchPattern, $searchPattern, $searchPattern);
}

$stmt->execute();
$allUsersResult = $stmt->get_result();

// Query to find users with incomplete forms excluding users already in All Users
$incompleteQuery = "
SELECT sd.studentUserId, sd.studentFirstName, sd.studentLastName
FROM studentdetails sd
LEFT JOIN academic a ON sd.studentUserId = a.academicUserId
LEFT JOIN document d ON sd.studentUserId = d.documentUserId
LEFT JOIN preference p ON sd.studentUserId = p.preferenceUserId
WHERE (a.academicUserId IS NULL OR d.documentUserId IS NULL OR p.preferenceUserId IS NULL)
AND sd.studentUserId NOT IN (
    SELECT DISTINCT studentUserId 
    FROM studentdetails
    LEFT JOIN preference ON studentdetails.studentUserId = preference.preferenceUserId
)
GROUP BY sd.studentUserId
";

$incompleteResult = $conn->query($incompleteQuery);

// Include admin header AFTER starting buffer
include '../header_admin.php';

// End output buffering to prevent errors
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
<style>
        /* Sidebar styles for larger screens */
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            color: #343a40;
            border-right: 1px solid #dee2e6;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .sidebar a {
            color: #495057;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-bottom: 1px solid #dee2e6;
        }

        .sidebar a:hover {
            background-color: #f8f9fa;
            color: #007bff;
        }

        /* Content area offset */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        /* Mobile menu styles */
        @media (max-width: 768px) {
            .sidebar {
                position: relative;
                height: auto;
                width: 100%;
            }

            .content {
                margin-left: 0;
            }

            .mobile-menu-btn {
                display: block;
            }
        }

        .mobile-menu-btn {
            display: none;
        }

        /* Header styles */
        .header {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .header .title {
            font-size: 24px;
            color: #343a40;
        }

        .header .logout-btn {
            color: #ffffff;
            background-color: #dc3545;
            border: none;
        }

        .header .logout-btn:hover {
            background-color: #c82333;
        }
    /* Adjust the header to create space below */
    .header {
        background-color: #ffffff;
        border-bottom: 1px solid #dee2e6;
        padding: 10px 20px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        position: fixed;
        width: 100%;
        top: 0;
        z-index: 1000;
    }

    /* Add margin to content to create space from the header */
    .content {
        margin-left: 250px;
        padding: 20px;
        margin-top: 70px; /* Adjust this value to move the content further down */
    }

    /* Sidebar adjustments for layout */
    .sidebar {
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        width: 250px;
        background-color: #ffffff;
        color: #343a40;
        border-right: 1px solid #dee2e6;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        overflow-y: auto;
        padding-top: 70px; /* Align sidebar content with the header */
    }

    /* Adjust for mobile menu */
    @media (max-width: 768px) {
        .sidebar {
            position: relative;
            height: auto;
            width: 100%;
            padding-top: 0;
        }

        .content {
            margin-left: 0;
            margin-top: 100px; /* Extra margin for mobile header height */
        }
    }
    /* General Styles */
body {
    font-family: 'Roboto', sans-serif;
    background-color: #f9f9f9;
    color: #333;
}
/* Adjust form alignment */
form.d-flex {
    gap: 15px;
}

form .form-select,
form .form-control {
    border-radius: 5px;
}

form .btn {
    font-size: 0.9rem;
}

/* Container */
.container {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
}

/* Header */
h2 {
    color: #4CAF50;
    font-weight: bold;
    margin-bottom: 20px;
}

/* Buttons */
.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    font-weight: 600;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #004085;
}

/* Table */
.table {
    margin-top: 20px;
}

.table thead th {
    background-color: #007bff;
    color: #fff;
    text-align: center;
    font-weight: bold;
    border-bottom: 2px solid #0056b3;
}

.table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

.table tbody td {
    vertical-align: middle;
    text-align: center;
}

.badge {
    padding: 5px 10px;
    font-size: 0.9rem;
    font-weight: bold;
    border-radius: 12px;
}

.bg-success {
    background-color: #28a745;
    color: #fff;
}

.bg-danger {
    background-color: #dc3545;
    color: #fff;
}

.bg-warning {
    background-color: #ffc107;
    color: #212529;
}

/* Form Styling */
form {
    margin-top: 15px;
}

form .form-control {
    border-radius: 5px;
}

form .btn {
    font-size: 0.9rem;
}

/* Dropdown */
select.form-select {
    max-width: 300px;
    margin: 10px auto;
}

/* Responsive Design */
@media (max-width: 768px) {
    .table {
        font-size: 0.9rem;
    }

    .btn {
        font-size: 0.8rem;
        padding: 8px 12px;
    }
}    .badge {
        display: inline-block;
        padding: 0.4em 0.7em;
        font-size: 0.85rem;
        font-weight: 600;
        text-align: center;
        border-radius: 0.25rem;
    }
    .bg-success {
        background-color: #28a745 !important;
        color: white !important;
    }
    .bg-danger {
        background-color: #dc3545 !important;
        color: white !important;
    }
    .bg-warning {
        background-color: #ffc107 !important;
        color: black !important;
    }
    .bg-secondary {
        background-color: #6c757d !important;
        color: white !important;
    }
    </style>
</head>
<body>
<!-- Sidebar for larger screens -->
<nav class="sidebar d-none d-md-block">
    <h4 class="text-center mt-3">Student Forms</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="form_a.php">Form A</a>
    <a href="form_b.php">Form B</a>
    <a href="form_c.php">Form C</a>
    <a href="form_d.php">Form D</a>
    <a href="form_e.php">Form E</a>
</nav>

<!-- Mobile menu toggle button -->
<div class="mobile-menu-btn d-md-none p-2 bg-dark text-white text-center">
    <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#mobileMenu" aria-expanded="false" aria-controls="mobileMenu">
        Menu
    </button>
</div>

<!-- Mobile menu -->
<div class="collapse d-md-none" id="mobileMenu">
    <nav class="bg-dark">
        <a href="dashboard.php" class="text-white">Dashboard</a>
        <a href="form_a.php" class="text-white">Form A</a>
        <a href="form_b.php" class="text-white">Form B</a>
        <a href="form_c.php" class="text-white">Form C</a>
        <a href="form_d.php" class="text-white">Form D</a>
        <a href="form_e.php" class="text-white">Form E</a>
    </nav>
</div>

<!-- Main content -->
<div class="content">
    <div class="container mt-4">
        <h2 class="text-center">Admin Dashboard</h2>

        <!-- Action Buttons -->
        <div class="text-center my-3">
            <a href="request.php" class="btn btn-primary">View Detailed Requests</a>
        </div>

        <form method="GET" class="d-flex justify-content-between align-items-center mb-4">
            <div class="d-flex align-items-center">
                <label for="department" class="form-label me-2 mb-0">Filter by Department</label>
                <select name="department" id="department" class="form-select me-3" style="max-width: 300px;" onchange="this.form.submit()">
                    <option value="">All Departments</option>
                    <option value="Civil Engineering" <?= $filterDepartment === 'Civil Engineering' ? 'selected' : '' ?>>Civil Engineering</option>
                    <option value="Mechanical Engineering" <?= $filterDepartment === 'Mechanical Engineering' ? 'selected' : '' ?>>Mechanical Engineering</option>
                    <option value="Electrical and Electronics Engineering" <?= $filterDepartment === 'Electrical and Electronics Engineering' ? 'selected' : '' ?>>Electrical and Electronics Engineering</option>
                    <option value="Electrical and Communication Engineering" <?= $filterDepartment === 'Electrical and Communication Engineering' ? 'selected' : '' ?>>Electrical and Communication Engineering</option>
                    <option value="Automobile Engineering" <?= $filterDepartment === 'Automobile Engineering' ? 'selected' : '' ?>>Automobile Engineering</option>
                    <option value="Textile Technology" <?= $filterDepartment === 'Textile Technology' ? 'selected' : '' ?>>Textile Technology</option>
                    <option value="Computer Technology" <?= $filterDepartment === 'Computer Technology' ? 'selected' : '' ?>>Computer Technology</option>
                    <option value="Printing Technology" <?= $filterDepartment === 'Printing Technology' ? 'selected' : '' ?>>Printing Technology</option>
                    <option value="Mechanical Engineering (R&AC)" <?= $filterDepartment === 'Mechanical Engineering (R&AC)' ? 'selected' : '' ?>>Mechanical Engineering (R&AC)</option>
                </select>
            </div>
            <div class="d-flex">
                <input type="text" name="search" class="form-control me-2" style="max-width: 300px;" placeholder="Search by name, phone, or school" value="<?= htmlspecialchars($searchQuery) ?>">
                <button type="submit" class="btn btn-secondary">Search</button>
            </div>
        </form>

        <!-- User Table -->
        <h3>All Users</h3>
        <div class="table-container">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone Number</th>
                        <th>School</th>
                        <th>Total Marks</th>
                        <th>Preference Departments</th>
                        <th>Preference Statuses</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $serialNumber = 0; 
                    while ($row = $allUsersResult->fetch_assoc()): 
                        $serialNumber++;
                    ?>
                        <tr>
                            <td><?= $serialNumber ?></td>
                            <td><?= htmlspecialchars($row['studentFirstName']) ?></td>
                            <td><?= htmlspecialchars($row['studentLastName']) ?></td>
                            <td><?= htmlspecialchars($row['studentPhoneNumber']) ?></td>
                            <td><?= htmlspecialchars($row['school_name']) ?></td>
                            <td><?= htmlspecialchars($row['totalMarks']) ?></td>
                            <td><?= htmlspecialchars($row['preferenceDepartments']) ?></td>
                            <td><?= htmlspecialchars($row['preferenceStatuses']) ?></td>
                            <td>
                                <a href="request.php?view=<?= $row['studentUserId'] ?>" class="btn btn-info btn-sm">View Details</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
