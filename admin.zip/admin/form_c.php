
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  
</div>
</body>
</html>
<?php
include '../include/db.php';
session_start();

if (!isset($_SESSION['userId'])) {
    header("Location: ../index.php");
    exit();
}

// Fetch all departments
$departmentQuery = "SELECT DISTINCT preferenceDepartment FROM preference";
$departmentResult = $conn->query($departmentQuery);
$departments = [];
while ($dept = $departmentResult->fetch_assoc()) {
    $departments[] = $dept['preferenceDepartment'];
}

// Initialize table structure
$tableData = [];
foreach ($departments as $department) {
    $tableData[$department] = [
        'shift' => 'First',
        'OC' => ['boys' => 0, 'girls' => 0],
        'BC' => ['boys' => 0, 'girls' => 0],
        'BCM' => ['boys' => 0, 'girls' => 0],
        'MBC' => ['boys' => 0, 'girls' => 0],
        'SCA' => ['boys' => 0, 'girls' => 0],
        'SC' => ['boys' => 0, 'girls' => 0],
        'ST' => ['boys' => 0, 'girls' => 0],
        'total' => ['boys' => 0, 'girls' => 0],
    ];
}

// Fetch student data
$query = "
SELECT p.preferenceDepartment, sd.studentGender, sd.studentCaste, COUNT(*) AS studentCount
FROM studentdetails sd
LEFT JOIN preference p ON sd.studentUserId = p.preferenceUserId
WHERE p.preferenceStatus = 'success'
GROUP BY p.preferenceDepartment, sd.studentCaste, sd.studentGender
";
$result = $conn->query($query);

// Populate table data
// Populate table data
while ($row = $result->fetch_assoc()) {
    $department = $row['preferenceDepartment'];
    $caste = $row['studentCaste'];
    $gender = strtolower($row['studentGender']); // Convert to lowercase for consistency
    $count = $row['studentCount'];

    // Map gender values to expected keys
    if ($gender === 'male' || $gender === 'm') {
        $gender = 'boys';
    } elseif ($gender === 'female' || $gender === 'f') {
        $gender = 'girls';
    } else {
        continue; // Skip if gender is undefined or invalid
    }

    if (isset($tableData[$department][$caste][$gender])) {
        $tableData[$department][$caste][$gender] += $count;
        $tableData[$department]['total'][$gender] += $count;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form B - Merit List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <style>
/* Sidebar styles for larger screens */
         .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            color: #343a40;
            border-right: 1px solid #dee2e6;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .sidebar a {
            color: #495057;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-bottom: 1px solid #dee2e6;
        }

        .sidebar a:hover {
            background-color: #f8f9fa;
            color: #007bff;
        }

        /* Content area offset */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        /* Mobile menu styles */
        @media (max-width: 768px) {
            .sidebar {
                position: relative;
                height: auto;
                width: 100%;
            }

            .content {
                margin-left: 0;
            }

            .mobile-menu-btn {
                display: block;
            }
        }

        .mobile-menu-btn {
            display: none;
        }

        /* Header styles */
        .header {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .header .title {
            font-size: 24px;
            color: #343a40;
        }

        .header .logout-btn {
            color: #ffffff;
            background-color: #dc3545;
            border: none;
        }

        .header .logout-btn:hover {
            background-color: #c82333;
        }
    /* Adjust the header to create space below */
    .header {
        background-color: #ffffff;
        border-bottom: 1px solid #dee2e6;
        padding: 10px 20px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        position: fixed;
        width: 100%;
        top: 0;
        z-index: 1000;
    }

    /* Add margin to content to create space from the header */
    .content {
        margin-left: 250px;
        padding: 20px;
        margin-top: 70px; /* Adjust this value to move the content further down */
    }

    /* Sidebar adjustments for layout */
    .sidebar {
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        width: 250px;
        background-color: #ffffff;
        color: #343a40;
        border-right: 1px solid #dee2e6;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        overflow-y: auto;
        padding-top: 70px; /* Align sidebar content with the header */
    }

    /* Adjust for mobile menu */
    @media (max-width: 768px) {
        .sidebar {
            position: relative;
            height: auto;
            width: 100%;
            padding-top: 0;
        }

        .content {
            margin-left: 0;
            margin-top: 100px; /* Extra margin for mobile header height */
        }
    }
</style>
<?php include '../header_admin.php'; ?>

<!-- Sidebar for larger screens -->
<nav class="sidebar d-none d-md-block">
    <h4 class="text-center mt-3">Student Forms</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="form_a.php">Form A</a>
    <a href="form_b.php">Form B</a>
    <a href="form_c.php">Form C</a>
    <a href="form_d.php">Form D</a>
    <a href="form_e.php">Form E</a>
</nav>

<!-- Mobile menu toggle button -->
<div class="mobile-menu-btn d-md-none p-2 bg-dark text-white text-center">
    <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#mobileMenu" aria-expanded="false" aria-controls="mobileMenu">
        Menu
    </button>
</div>

<!-- Mobile menu -->
<div class="collapse d-md-none" id="mobileMenu">
    <nav class="bg-dark">
        <a href="dashboard.php" class="text-white">Dashboard</a>
        <a href="form_a.php" class="text-white">Form A</a>
        <a href="form_b.php" class="text-white">Form B</a>
        <a href="form_c.php" class="text-white">Form C</a>
        <a href="form_d.php" class="text-white">Form D</a>
        <a href="form_e.php" class="text-white">Form E</a>
    </nav>
</div>
<div class="content">
    <div class="container mt-4">
    <h2 class="text-center">Admission to First Year Diploma Courses (2024-2025)</h2>
    <table class="table table-bordered">
        <thead class="thead-dark">
        <tr>
            <th>S.No</th>
            <th>Department</th>
            <th>Shift</th>
            <th>OC (B)</th>
            <th>OC (G)</th>
            <th>BC (B)</th>
            <th>BC (G)</th>
            <th>BCM (B)</th>
            <th>BCM (G)</th>
            <th>MBC (B)</th>
            <th>MBC (G)</th>
            <th>SCA (B)</th>
            <th>SCA (G)</th>
            <th>SC (B)</th>
            <th>SC (G)</th>
            <th>ST (B)</th>
            <th>ST (G)</th>
            <th>Total (B)</th>
            <th>Total (G)</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $serialNumber = 1;
        foreach ($tableData as $department => $data) {
            echo "<tr>";
            echo "<td>{$serialNumber}</td>";
            echo "<td>{$department}</td>";
            echo "<td>{$data['shift']}</td>";
            echo "<td>{$data['OC']['boys']}</td>";
            echo "<td>{$data['OC']['girls']}</td>";
            echo "<td>{$data['BC']['boys']}</td>";
            echo "<td>{$data['BC']['girls']}</td>";
            echo "<td>{$data['BCM']['boys']}</td>";
            echo "<td>{$data['BCM']['girls']}</td>";
            echo "<td>{$data['MBC']['boys']}</td>";
            echo "<td>{$data['MBC']['girls']}</td>";
            echo "<td>{$data['SCA']['boys']}</td>";
            echo "<td>{$data['SCA']['girls']}</td>";
            echo "<td>{$data['SC']['boys']}</td>";
            echo "<td>{$data['SC']['girls']}</td>";
            echo "<td>{$data['ST']['boys']}</td>";
            echo "<td>{$data['ST']['girls']}</td>";
            echo "<td>{$data['total']['boys']}</td>";
            echo "<td>{$data['total']['girls']}</td>";
            echo "</tr>";
            $serialNumber++;
        }
        ?>
        </tbody>
    </table>
            </div>
</div>
</body>
</html>
