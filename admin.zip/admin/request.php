<?php
ob_start(); // Start output buffering
include '../include/db.php';
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

if (!isset($_SESSION['userId'])) {
    header("Location: ../auth/login.php");
    exit();
}

$adminId = $_SESSION['userId'];
$studentUserId = $_GET['view'] ?? null;

if ($studentUserId) {
    // Fetch student details, academic info, preferences, and documents
    $query = "
    SELECT sd.studentUserId, sd.studentFirstName, sd.studentLastName, sd.studentPhoneNumber, sd.studentReligion, sd.studentCaste_2, 
           sd.studentMotherTongue, sd.studentFatherName, sd.studentMotherName, sd.studentDateOfBirth, sd.studentGender, sd.studentCaste,
           a.school_name, a.totalMarks, a.yearOfPassing, a.tamilMarks, a.englishMarks, a.mathsMarks, a.scienceMarks, a.socialScienceMarks, 
           a.otherLanguageMarks, p.preferenceId, p.preferenceDepartment, p.preferenceStatus, u.userEmail
    FROM studentdetails sd
    LEFT JOIN academic a ON sd.studentUserId = a.academicUserId
    LEFT JOIN preference p ON sd.studentUserId = p.preferenceUserId
    LEFT JOIN users u ON sd.studentUserId = u.userId
    WHERE sd.studentUserId = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $studentUserId);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    // Fetch documents uploaded by the student
    $documentQuery = "SELECT * FROM document WHERE documentUserId = ?";
    $docStmt = $conn->prepare($documentQuery);
    $docStmt->bind_param("i", $studentUserId);
    $docStmt->execute();
    $documentsResult = $docStmt->get_result();

    // Fetch preferences for the student (multiple preferences)
    $preferencesQuery = "
    SELECT p.preferenceId, p.preferenceDepartment, p.preferenceStatus 
    FROM preference p 
    WHERE p.preferenceUserId = ? 
    ORDER BY p.preferenceOrder ASC";
    
    $prefStmt = $conn->prepare($preferencesQuery);
    $prefStmt->bind_param("i", $studentUserId);
    $prefStmt->execute();
    $preferencesResult = $prefStmt->get_result();

    $preferences = [];
    while ($row = $preferencesResult->fetch_assoc()) {
        $preferences[] = $row;
    }
} else {
    header("Location: dashboard.php");
    exit();
}

// Handle approve, reject, and reset actions for preferences
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['preference_action'] as $preferenceId => $action) {
        $preferenceStatus = match ($action) {
            'approve' => 'success',
            'reject' => 'rejected',
            'reset' => 'reset',
            default => null,
        };

        if ($preferenceStatus) {
            $updateQuery = "UPDATE preference SET preferenceStatus = ? WHERE preferenceId = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("si", $preferenceStatus, $preferenceId);
            $stmt->execute();

            // Get the preference details for email
            $preference = array_filter($preferences, fn($p) => $p['preferenceId'] == $preferenceId)[0];
            sendStatusEmail(
                $student['userEmail'],
                $student['studentFirstName'],
                $student['studentLastName'],
                $preferenceStatus,
                $preference['preferenceDepartment']
            );
        }
    }

    $_SESSION['action_message'] = "Preferences updated successfully!";
    $_SESSION['action_status'] = 'success';
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit();
}

// Function to send the status email to the student
function sendStatusEmail($toEmail, $firstName, $lastName, $status, $department) {
    $mail = new PHPMailer(true);

    // Enable debugging to catch any email sending errors
    $mail->SMTPDebug = 0;  // Disable debugging in production

    try {
        $subject = match ($status) {
            'success' => "Application Approved for $department",
            'rejected' => "Application Rejected for $department",
            'reset' => "Reapply for $department Application",
            default => "Application Update for $department",
        };

        $statusMessage = match ($status) {
            'success' => "Congratulations! Your application has been approved. We look forward to welcoming you.",
            'rejected' => "We regret to inform you that your application has been rejected. Please contact us for further information.",
            'reset' => "Oops! Your application has been reset. We request you to reapply.",
            default => "Your application status has been updated. Please check your account for details.",
        };

        $body = "
        <div style='font-family: Arial, sans-serif; font-size: 16px; color: #333; background: linear-gradient(to bottom, #ffffff, #f0f8ff); padding: 20px; border-radius: 10px;'>
            <p>Dear <strong>$firstName $lastName</strong>,</p>
            <p>Your application for the department <strong>$department</strong> has been updated with the status:
                <strong style='color: " . ($status === 'success' ? '#28a745' : ($status === 'rejected' ? '#dc3545' : '#ffc107')) . ";'>
                    " . ucfirst($status) . "
                </strong>
            </p>
            <p>$statusMessage</p>
            <p>If you have any questions, please feel free to contact us at <a href='mailto:admission@nptc.ac.in'>admission@nptc.ac.in</a>.</p>
            <p>Best regards,<br><strong>The Admin Team</strong></p>
        </div>";

        // Email settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'sathancreator@gmail.com'; // Gmail address
        $mail->Password = 'tatqezizskzqjgqg'; // Use an app-specific password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('sathancreator@gmail.com', 'admission@nptc.ac.in');
        $mail->addAddress($toEmail, "$firstName $lastName");

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;

        $mail->send();
        return true; // Email sent successfully
    } catch (Exception $e) {
        error_log("Email sending failed: " . $mail->ErrorInfo);
        return false; // Email failed
    }
}

ob_end_flush(); // Flush the output buffer to send all content
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Request Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2, h4 {
            border-bottom: 2px solid #007bff;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }
        .btn {
            margin-right: 5px;
        }
        table th, table td {
            vertical-align: middle;
        }
        .badge-success { background-color: #28a745; }
        .badge-danger { background-color: #dc3545; }
        .badge-warning { background-color: #ffc107; color: #212529; }
        .img-thumbnail {
            max-width: 100%;
            max-height: 200px;
            object-fit: cover;
        }
        .action-buttons {
            margin-top: 20px;
        }
        .table-container {
            overflow-x: auto;
        }
    </style>
</head>
<body>
<?php include '../header_admin.php'; ?>

<div class="container mt-4">
    <h2>Student Request Details</h2>
    <h4>Personal Information</h4>
    <table class="table">
        <tr><th>First Name</th><td><?= htmlspecialchars($student['studentFirstName']) ?></td></tr>
        <tr><th>Last Name</th><td><?= htmlspecialchars($student['studentLastName']) ?></td></tr>
        <tr><th>Father's Name</th><td><?= htmlspecialchars($student['studentFatherName']) ?></td></tr>
        <tr><th>Mother's Name</th><td><?= htmlspecialchars($student['studentMotherName']) ?></td></tr>
        <tr><th>Date of Birth</th><td><?= htmlspecialchars($student['studentDateOfBirth']) ?></td></tr>
        <tr><th>Gender</th><td><?= htmlspecialchars($student['studentGender']) ?></td></tr>
        <tr><th>Religion</th><td><?= htmlspecialchars($student['studentReligion']) ?></td></tr>
        <tr><th>Community</th><td><?= htmlspecialchars($student['studentCaste']) ?></td></tr>    
        <tr><th>Caste</th><td><?= htmlspecialchars($student['studentCaste_2']) ?></td></tr>
        <tr><th>Mother Tongue</th><td><?= htmlspecialchars($student['studentMotherTongue']) ?></td></tr>
        <tr><th>Email</th><td><?= htmlspecialchars($student['userEmail']) ?></td></tr>
        <tr><th>Phone Number</th><td><?= htmlspecialchars($student['studentPhoneNumber']) ?></td></tr> 
    </table>

    <h4>Academic Information</h4>
    <table class="table">
        <tr><th>School</th><td><?= htmlspecialchars($student['school_name']) ?></td></tr>
        <tr><th>Year Of passing</th><td><?= htmlspecialchars($student['yearOfPassing']) ?></td></tr>
        <tr><th>Tamil</th><td><?= htmlspecialchars($student['tamilMarks']) ?></td></tr>
        <tr><th>English</th><td><?= htmlspecialchars($student['englishMarks']) ?></td></tr>
        <tr><th>Maths</th><td><?= htmlspecialchars($student['mathsMarks']) ?></td></tr>
        <tr><th>Science</th><td><?= htmlspecialchars($student['scienceMarks']) ?></td></tr>
        <tr><th>Social Science</th><td><?= htmlspecialchars($student['socialScienceMarks']) ?></td></tr>
        <tr><th>Other Language</th><td><?= htmlspecialchars($student['otherLanguageMarks']) ?></td></tr>
        <tr><th>Total Marks</th><td><?= htmlspecialchars($student['totalMarks']) ?></td></tr>
    </table>
    
    <h4>Uploaded Documents</h4>
    <?php if ($documentsResult->num_rows > 0): ?>
        <div class="row">
            <?php while ($document = $documentsResult->fetch_assoc()): ?>
                <?php 
                $files = json_decode($document['documentName'], true); 
                ?>
                <?php foreach ($files as $type => $fileName): ?>
                    <div class="col-md-4 text-center mb-3">
                        <?php if (preg_match('/\.(jpg|jpeg|png)$/i', $fileName)): ?>
                            <img src="../documents/<?= htmlspecialchars($fileName) ?>" 
                                 alt="<?= htmlspecialchars($type) ?>" 
                                 class="img-thumbnail border rounded shadow-sm">
                            <p class="text-muted"><?= ucfirst($type) ?></p>
                        <?php else: ?>
                            <p class="text-muted"><?= ucfirst($type) ?>: <?= htmlspecialchars($fileName) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?> 
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p>No documents uploaded.</p>
    <?php endif; ?>


    <h4>Preferences</h4>
    <form action="" method="POST">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Preference Department</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($preferences as $preference): ?>
                    <tr>
                        <td><?= htmlspecialchars($preference['preferenceDepartment']) ?></td>
                        <td>
                            <span class="badge 
                                <?= $preference['preferenceStatus'] === 'success' ? 'badge-success' : 
                                   ($preference['preferenceStatus'] === 'rejected' ? 'badge-danger' : 
                                   ($preference['preferenceStatus'] === 'reset' ? 'badge-warning' : 'badge-secondary')) ?>">
                                <?= ucfirst($preference['preferenceStatus']) ?>
                            </span>
                        </td>
                        <td>
                            <div>
                                <label class="me-3">
                                    <input type="radio" name="preference_action[<?= $preference['preferenceId'] ?>]" value="approve"> Approve
                                </label>
                                <label class="me-3">
                                    <input type="radio" name="preference_action[<?= $preference['preferenceId'] ?>]" value="reject"> Reject
                                </label>
                                <label>
                                    <input type="radio" name="preference_action[<?= $preference['preferenceId'] ?>]" value="reset"> Reset
                                </label>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (isset($_SESSION['action_message'])): ?>
            Swal.fire({
                icon: '<?= $_SESSION['action_status'] ?>',
                title: '<?= $_SESSION['action_message'] ?>',
                showConfirmButton: false,
                timer: 1500
            });
            <?php unset($_SESSION['action_message'], $_SESSION['action_status']); ?>
        <?php endif; ?>
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
